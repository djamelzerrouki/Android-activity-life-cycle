
Run tests
---------

    ./gradlew connectedInstrumentTest
